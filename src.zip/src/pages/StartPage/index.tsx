import { observer } from "mobx-react";
import React from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";

const StartPage = (): JSX.Element => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate("/tournament");
  };

  return (
    <div className="container">
      <ImageBg />
      <StartButton onClick={handleClick}>Start!</StartButton>
    </div>
  );
};

export default observer(StartPage);

const ImageBg = styled.div`
  width: 900px;
  height: 600px;
  background-image: url("./image/home(960_634).png");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  margin: 0 auto 20px;
  border-radius: 3px;
`;

const StartButton = styled.button`
  display: block;
  width: 100px;
  height: 35px;
  font-size: 23px;
  font-weight: 800;
  border-radius: 7px;
  margin: auto;
  color: ${(props) => props.theme.homeButtonColor};
  background-color: ${(props) => props.theme.headerColor};
`;
