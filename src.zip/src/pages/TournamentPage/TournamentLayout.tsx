import React from "react";
import { Outlet } from "react-router-dom";

const TournamentLayout = (): JSX.Element => {
  return (
    <div className="container">
      <Outlet />
    </div>
  );
};

export default TournamentLayout;
