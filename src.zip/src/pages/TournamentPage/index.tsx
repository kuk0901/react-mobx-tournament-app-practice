import React from "react";

const TournamentPage = () => {
  return <div></div>;
};

export default TournamentPage;
