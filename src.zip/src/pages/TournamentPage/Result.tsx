import React from "react";

const Result = (): JSX.Element => {
  return <div></div>;
};

export default Result;
