// import { createContext, useContext } from "react";
import ThemeStore from "./theme";

export interface Store {
  theme: ThemeStore;
}

export const store: Store = {
  theme: new ThemeStore()
};
