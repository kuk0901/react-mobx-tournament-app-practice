import React from "react";

const ImageBox = (): JSX.Element => {
  return <div></div>;
};

export default ImageBox;
