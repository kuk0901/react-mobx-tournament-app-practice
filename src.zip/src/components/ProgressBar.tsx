import React from "react";

const ProgressBar = (): JSX.Element => {
  return <div></div>;
};

export default ProgressBar;
