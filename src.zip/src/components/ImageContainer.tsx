import React from "react";

const ImageContainer = (): JSX.Element => {
  return <div></div>;
};

export default ImageContainer;
