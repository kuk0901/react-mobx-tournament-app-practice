import React from "react";

const ResultImage = (): JSX.Element => {
  return <div></div>;
};

export default ResultImage;
